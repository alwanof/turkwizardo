<?php

return [
    'menu'=>[
        'category'=>'الفئة',
        'city'=>'المدينة',
        'website'=>'الموقع الاكتروني',
        'description'=>'وصف المصنع',
        'products'=>'المنتجات ',
        'gallery'=>'الصور',
    ],

];
