<?php

return [
    'hint'=>[
        'part1'=>'If you do not find factory or product please ',
        'search'=>'Click here',
        'part2'=>' to go search page or simply contact us using query form ',
    ],

];
