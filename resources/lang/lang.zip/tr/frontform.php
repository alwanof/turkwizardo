<?php

return [
    'menu'=>[
        'title'=>'nasıl yardımcı olabiliriz',
        'name'=>'adınız',
        'email'=>'e-posta',
        'phone'=>'telefon numaranız',
        'note'=>'notlarınız',
        'service_title'=>'servisi seçiniz',
        'service'=>[
            'Fabrikalar listesi',
            'fiyat teklifleri',
            'fabrikalara ulaşım',
            'siparişiniz takip etmek ve tamamlamak',

        ],

    ],
    'send_query'=>'Sorgu Gönder'

];
