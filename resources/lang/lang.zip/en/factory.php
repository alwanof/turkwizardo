<?php

return [
    'menu'=>[
        'category'=>'Category',
        'city'=>'City',
        'website'=>'Website',
        'description'=>'Description',
        'products'=>'Products',
        'gallery'=>'Gallery',
    ],

];
