<?php

return [
    'menu'=>[
        'title'=>'Request VIP Service',
        'name'=>'Your Name',
        'email'=>'Your Email',
        'phone'=>'Your Phone No.',
        'note'=>'Your Note',
        'service_title'=>'Select Service',
        'service'=>[
            'Send me factories list',
            'Send me prices list',
            'Delivery and recommendation',
            'Follow the deal',

        ],

    ],
    'send_query'=>'Send Query'

];
