<?php

return [
    'hint'=>[
        'part1'=>'If you do not find factory ',
        'search'=>'Click here',
        'part2'=>' to go search page.',
    ],

];
