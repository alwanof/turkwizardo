<?php

return [
    'menu'=>[
        'home'=>'Home',
        'about'=>'About us',
        'services'=>[
            'parent'=>'Services',
            'free'=>'Free Services',
            'paid'=>'Paid Services'
        ],
        'contact'=>'Contact us',
        'add_your_factory'=>'Add your Factory',
        'search'=>'Search',
        'search_hint'=>'Search for anything..',
        'recommended'=>'Recommended',
        'most_popular'=>'Most Popular',
        'categories'=>'Categories'

    ],

];
