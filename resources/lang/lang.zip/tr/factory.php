<?php

return [
    'menu'=>[
        'category'=>'Kategori',
        'city'=>'şehir',
        'website'=>'web sitesi',
        'description'=>'fabrika hakkında ',
        'products'=>'ürünler',
        'gallery'=>'resimler',
    ],

];
