<?php

return [
    'menu'=>[
        'home'=>'الصفحة الرئيسية',
        'about'=>'من نحن',
        'services'=>[
            'parent'=>'خدماتنا',
            'free'=>'الخدمات المجانية',
            'paid'=>'الخدمات المدفوعة'
        ],
        'contact'=>'تواصل معنا',
        'add_your_factory'=>'من اجل مصانعنا',
        'search'=>'البحث',
        'search_hint'=>' ابحث عن مصنع او منتج..',
        'recommended'=>'الموصى بها',
        'most_popular'=>'الاكثر زيارة',
        'categories'=>'الأصناف'




    ],

];
