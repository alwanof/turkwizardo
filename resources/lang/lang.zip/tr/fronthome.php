<?php

return [
    'menu'=>[
        'home'=>'anasayfa',
        'about'=>'hakkımızda',
        'services'=>[
            'parent'=>'hizmetler',
            'free'=>'ücretsiz hizmetler',
            'paid'=>'ücretli hizmetler'
        ],
        'contact'=>'iletişim',
        'add_your_factory'=>'fabrikalara hizmet',
        'search'=>'ara',
        'search_hint'=>'istediğin şeyi bul..',
        'recommended'=>'tavsiye',
        'most_popular'=>'en çok ziyaret',
        'categories'=>'Kategoriler'




    ],

];
